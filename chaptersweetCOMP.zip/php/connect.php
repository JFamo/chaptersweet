<?php

require_once('config.php');

$link = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD);

if (!$link){
	die('Could not connect: ' . mysqli_error());
}

$db_selected = mysqli_select_db(DB_NAME,$link);

if (!$db_selected){
	die('Connot use: ' . mysqli_error());
}

?>