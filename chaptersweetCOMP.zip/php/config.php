<?php
//define database name as resumix - for use with local MySQL database (currently XAMPP)
define('DB_NAME', 'chapters_chaptersweet');
//access via root user
//TODO - make a seperate user for this program
define('DB_USER', 'chapters_root');
//password (super secret)
//~~~NOTE TO SELF~~~ change this before uploading to github
//dont want any
//	~~~~~~~~SPOOOKY~~~~~~~~~~~~
//  ~~~~~~~~~~~~~~HACKER~~~~~~~
//  ~~~~PEOPLE~~~~~~~~~~~~~~~~~
//seeing this
define('DB_PASSWORD', 'mypass');
//define host as localhost, connecting to own machine
define('DB_HOST', 'localhost');
//charset is utf8, latin
define('DB_CHARSET', 'utf8');
?>